package com.ripple.permission.plugin.log;

/**
 * Author: fanyafeng
 * Data: 2020/4/13 20:30
 * Email: fanyafeng@live.cn
 * Description:
 */
public class LogUtil {

    public static void i(String message) {
        System.out.println("permission_plugin:--------->" + message);
    }


    public static void d(String message) {
        System.out.println("permission_plugin:--------->" + message);
    }
}
